---
title: "pi-acp v0.6: Long-Running Daemon + Thin-Client Binary"
prd: PRD-003
status: Draft
owner: "Victor Araujo"
issue: "N/A"
date: 2026-05-19
version: "1.0"
---

# PRD: pi-acp v0.6 — Long-Running Daemon + Thin-Client Binary

---

## 1. Problem & Context

pi-acp `v0.5` is a per-spawn ACP adapter: every time an ACP client (Zed window, CLI invocation, etc.) launches `pi-acp`, a fresh Node process is born, embedded pi initializes from scratch, and any in-memory state lives only for that connection's lifetime. When the connection closes, the process exits and all state is gone.

Three real costs land on the user:

1. **No cross-window session visibility.** Open Zed window A, start session, write 30 messages. Open Zed window B (same project or different) — `session/list` shows nothing from window A because A's process is a separate sandbox. Resume from disk works (pi persists sessions to `~/.pi/agent/sessions/`) but only via explicit session-id lookup; the natural "show me my active sessions" surface fails.
2. **Startup cost N times.** Each ACP client spawn = ~200ms of Node start + pi init + manifest evaluation (under PRD-002). For users who open many Zed windows or run pi-acp from a quick-action menu, this is felt.
3. **No in-memory cache sharing.** PRD-002 introduces SSH ControlMaster connections, HTTP TTL caches, parsed manifests, and per-cwd `VirtualResourceLoader` instances. With per-spawn pi-acp, every spawn rebuilds these. Multiple Zed windows for the same project pay the cost N times.

`v0.5` filesystem-backed state covers some of this:

- pi sessions persist to `~/.pi/agent/sessions/...` and are listable via `SessionManager.listAll()`.
- Auth state in `~/.pi/agent/auth.json`.
- Model registry in `~/.pi/agent/models.json`.

But filesystem-shared state cannot carry **in-memory connection pools, parsed-manifest caches, or live session handles**. Those are precisely the costs PRD-002 introduces. Without an orchestrator, every PRD-002 backend pays its setup cost on every spawn.

ACP is per-spawn by design — clients launch the agent via `agent_servers.<name>.command`, hand it stdio, and treat its lifetime as scoped to the connection. The spec does not contemplate a long-running orchestrator. Fighting that takes work, but the work is bounded: keep the spawn surface intact (the binary still accepts stdio and speaks ACP), make the binary a forwarder to a long-running daemon that owns the actual ACP server. Each spawn = thin client. The daemon = orchestrator for all of them.

### What "daemon" buys (concrete)

- **Cross-window session visibility.** Daemon-level `SessionRegistry` keys live `AgentSession`s by sessionId; every connected client sees the union via `session/list`.
- **Shared SSH ControlMaster connections.** First spawn opens the master; subsequent spawns reuse the multiplexed channel. Per-op latency drops from ~150ms to ~5ms.
- **Shared HTTP TTL cache.** First spawn fetches; cache hits for the lifetime of the daemon, across all clients.
- **Shared parsed manifest.** Per-cwd manifest is parsed once; cached by stat-mtime.
- **Single pi runtime.** Model registry, extension runner, auth storage instantiated once. New `AgentSession`s built from that shared base.
- **Constant fast startup.** New client connections complete handshake in <50ms once daemon is warm.

### What "daemon" does NOT change

- ACP wire surface — still JSON-RPC NDJSON over stdio, from the client's perspective.
- Per-session semantics — each `AgentSession` still has its own message stream, abort handle, tool state.
- Pi runtime model — `createAgentSession({...})` still constructs one session at a time.
- `--terminal-login` flow — still spawns pi directly in the foreground (does NOT go through daemon).
- Per-client capabilities — each ACP connection negotiates its own `clientCapabilities`.

---

## 2. Goals & Success Metrics

| Goal | Metric | Target |
|------|--------|--------|
| **Long-running daemon** | Single process holds all live `AgentSession`s for one user | One daemon process per UID after first spawn |
| **Thin-client binary** | `pi-acp` (without `--daemon`) is socket forwarder | `dist/index.mjs` < 20kB minified for the client path |
| **Auto-spawn** | First client invocation that finds no daemon spawns one | Verified by integration test |
| **Auto-shutdown** | Daemon exits cleanly after configurable idle period | Default 600s after last client disconnect; tunable via env var |
| **Cross-window session visibility** | `session/list` returns sessions from all currently-connected clients of the same daemon | Verified by integration test |
| **Shared SSH ControlMaster** | Second spawn reuses ssh-master from first spawn | SSH op latency < 20ms on second invocation (vs ~150ms cold) |
| **Backward compat** | Existing `agent_servers` configs in Zed work unchanged | No client config changes required |
| **Terminal-login unchanged** | `pi-acp --terminal-login` still spawns pi directly | Doesn't engage daemon at all |
| **Crash isolation** | One client misbehaving does not affect other clients | Per-connection error containment; daemon survives client crashes |

**Guardrails (must not regress):**

- Daemon is the only runtime mode. There is no per-spawn fallback. *(Updated v1.1 — the `PI_ACP_NO_DAEMON=1` escape hatch and `runtime/in-process.ts` were removed during the v0.6 foundation refactor before any v0.6 phase shipped.)*
- ACP protocol semantics unchanged.
- v0.5 reactive auth path stays identical.
- Existing 186 tests pass unmodified.
- `bin: pi-acp` shape preserved; bin still callable with stdio by Zed.
- Semantic-release pipeline unchanged.

---

## 3. Users & Use Cases

### Primary: Multi-window Zed user

> As a developer with three Zed windows open on the same project, I want to start a long pi session in window 1, then resume it in window 2 (e.g., my laptop screen vs external monitor split), seeing it in `session/list` without manually copying a session ID.

### Primary: Quick-action user

> As a developer who opens pi-acp from a Raycast/Alfred quick action many times per day, I want subsequent invocations to feel instant — not the 200ms cold-start of a fresh Node + pi load.

### Primary: PRD-002 SSH-resource user

> As a user with an `ssh` resource source pointing at my dev VM, I want the first session to open the SSH ControlMaster connection and every subsequent session in any window to reuse that master, not re-handshake.

### Secondary: Single-window user (status quo)

> As a developer who only ever has one Zed window open, I want pi-acp to work exactly as it did in v0.5 — no daemon-related surprises, no extra processes I have to manage. The daemon spawns silently, idles out silently, no visible behavior change.

### Secondary: Operator debugging

> As an operator, I want to inspect daemon state (`pi-acp --daemon-status`), see what clients are connected, and force-kill the daemon if it misbehaves (`pi-acp --daemon-stop`).

---

## 4. Scope

### In scope (v0.6 — PRD-003 part)

1. **Daemon mode.** New `pi-acp --daemon` flag runs the long-running process. Hosts shared singletons: `SessionRegistry`, `ResourceLoaderPool`, `SshPool`, `HttpCache`, `ManifestCache`. Listens on a per-user Unix domain socket. *(Updated v1.1 — Posix-only; Windows named-pipe path dropped.)*
2. **Thin-client mode.** Default `pi-acp` (no flag) is the forwarder. Connects to the daemon's socket; if absent, auto-spawns daemon then connects. Pipes `process.stdin → socket` and `socket → process.stdout`. Exit when socket closes.
3. **Per-connection ACP server inside daemon.** Each incoming socket connection gets its own `AgentSideConnection` wrapping the socket; one `PiAcpAgent` instance per connection, sharing daemon-level singletons via dependency injection.
4. **`SessionRegistry`** — daemon-level singleton map `sessionId → { piSession, ownerConnectionId, refCount }`. Sessions outlive the connection that created them when `refCount > 0` (e.g., another client also opened them).
5. **Auto-spawn.** Client tries to `connect()` to socket. On `ENOENT` / `ECONNREFUSED` / stale-socket, client forks `pi-acp --daemon` detached, waits up to 3s polling, then connects. Lockfile (`<socket>.lock`) prevents duplicate spawns.
6. **Idle shutdown.** Daemon tracks active connections. When count drops to 0, starts a timer (default 600s, configurable via `PI_ACP_DAEMON_IDLE_SECONDS`). Timer cancelled on next connection. Timer fire → graceful shutdown.
7. **Operator commands.** `--daemon-status` prints connections / sessions / uptime. `--daemon-stop` sends shutdown to a running daemon. Both go through the dedicated control socket (Hono HTTP over UDS). *(Updated v1.1 — `PI_ACP_NO_DAEMON=1` removed; daemon is the only runtime path.)*
8. **`--terminal-login` bypass.** Continues to spawn pi directly in the foreground; never touches the daemon.

### Out of scope / deferred

| What | Why | Tracked in |
|------|-----|------------|
| Daemon across multiple machines | True distributed orchestration is a different category of problem. | Future PRD |
| Network-exposed daemon (TCP) | Unix-socket is fine for one user on one machine. Network exposure has auth/TLS demands. | Future PRD |
| Cross-user daemon | One daemon per UID. Multi-user requires permission model not designed here. | Future PRD |
| Daemon-side ACP transport translation | Daemon talks ACP NDJSON-over-stream the same way the v0.5 process did. No re-framing. | N/A |
| Hot-reload daemon binary | Daemon must restart for code updates. v0.5 install model. | N/A |
| Per-connection rate limits / quotas | One user, one machine — quota policy is overkill. | Future PRD |
| MCP server wiring per session | Still blocked on pi SDK exposing per-session MCP config. | PRD-001 follow-up |

### Design for future (build with awareness)

- **Network transport.** The socket layer should be a thin abstraction over `stream.Duplex` so swapping unix-socket for TCP+TLS is a transport-layer change, not a daemon-internals change.
- **Cross-user daemon.** Per-UID socket path now (`pi-acp-${UID}.sock`); if cross-user ever lands, the path naming pattern leaves room.

---

## 5. Functional Requirements

### FR-1: Daemon process

`pi-acp --daemon` launches the long-running orchestrator.

Responsibilities:

- Bind the ACP Unix socket at `~/.pi/run/pi-acp.sock` and the control-plane Unix socket at `~/.pi/run/pi-acp-control.sock` (override base dir via `PI_ACP_SOCKET_DIR`). *(Updated v1.1 — Posix-only; relocated from `${XDG_RUNTIME_DIR:-/tmp}/pi-acp-${UID}.sock`.)*
- Acquire `~/.pi/run/pi-acp.lock` exclusive lock (PID-tracked). Refuse to start if another daemon already owns it.
- Construct daemon-level singletons:
  - `SessionRegistry`
  - `ResourceLoaderPool` (per-manifest-hash keyed)
  - `SshPool` (per-host keyed, ControlMaster lifecycle)
  - `HttpCache` (URL+TTL keyed)
  - `ManifestCache` (per-cwd keyed by stat-mtime)
- Listen for connections. Per connection, create `AgentSideConnection` + `PiAcpAgent` with shared-state DI.
- Track connection count. On count → 0, start idle timer. On count > 0, cancel timer.
- On idle timer fire OR SIGTERM/SIGINT: gracefully shut down — close all `PiAcpAgent`s, dispose all `AgentSession`s, release singletons, remove socket file + lockfile, exit 0.

**Acceptance criteria:**

```gherkin
Given pi-acp --daemon is invoked and no daemon currently running
When the daemon binds the socket
Then a UNIX socket file appears at the configured path
And a <socket>.lock file with the daemon PID appears
And the daemon process holds the file lock

Given a daemon is already running
When pi-acp --daemon is invoked again
Then the second invocation prints an error containing "already running" with the running PID
And exits with code 1

Given a daemon with no connected clients
When the idle timeout elapses
Then the daemon disposes all singletons, removes the socket file and lockfile, and exits 0
```

### FR-2: Thin-client binary

Default invocation (`pi-acp` with no flag) is the forwarder.

Logic:

```ts
const socketPath = computeSocketPath();
let socket = tryConnect(socketPath);
if (!socket) {
  await spawnDaemon();              // pi-acp --daemon, detached
  socket = await waitForSocket(socketPath, { timeoutMs: 3000 });
}
process.stdin.pipe(socket);
socket.pipe(process.stdout);
socket.on("close", () => process.exit(0));
process.on("SIGINT", () => socket.destroy());
process.on("SIGTERM", () => socket.destroy());
```

Console redirect block from PRD-001 FR-5 stays — even in client mode, stray bytes on stdout corrupt the ACP frame stream coming back from the daemon.

`--terminal-login` flag takes precedence over client mode — invokes pi directly in the foreground, never touches the socket.

*(Rescinded in v1.1: the `PI_ACP_NO_DAEMON=1` escape hatch was removed during the v0.6 foundation refactor before any v0.6 phase shipped. The daemon is the only runtime path; there is no in-process fallback.)*

**Acceptance criteria:**

```gherkin
Given no daemon currently running
When pi-acp is invoked with ACP JSON-RPC on stdin
Then the client spawns a daemon, waits for the socket, then forwards stdin to the daemon
And the daemon's response frames appear on the client's stdout

Given a daemon is already running
When pi-acp is invoked
Then the client connects to the existing socket within 50ms
And no additional daemon process spawns
```

### FR-3: Per-connection ACP server in daemon

Each socket connection accepted by the daemon spawns:

```ts
const stream = ndJsonStream(socketIn, socketOut);
const conn = new AgentSideConnection(
  (acp) => new PiAcpAgent(acp, {
    sessionRegistry,
    resourceLoaderPool,
    sshPool,
    httpCache,
    manifestCache,
  }),
  stream,
);
```

`PiAcpAgent` constructor signature extended to accept a `daemonContext` arg holding the shared singletons. Sessions created by this agent register into `sessionRegistry` keyed by `sessionId` with `ownerConnectionId`. `closeSession` decrements `refCount`; only when `refCount === 0` does the underlying `AgentSession` dispose.

Per-client state kept on the `PiAcpAgent` instance:
- `clientCapabilities` (from `initialize`)
- Owned `sessionId` set
- Current ACP `connection` reference (for `fs/read_text_file` callbacks etc.)

Shared state lives in `daemonContext`.

**Acceptance criteria:**

```gherkin
Given two clients connected to the same daemon
When client A creates session X via session/new
Then session X is registered in the SessionRegistry
And client B's session/list response includes session X

Given client A owns session X and calls closeSession
When no other client references session X
Then refCount drops to 0 and the underlying AgentSession is disposed

Given client A owns session X and calls closeSession
When client B has also resumed session X
Then refCount stays > 0 and the AgentSession is NOT disposed
```

### FR-4: Socket path + lockfile

Per-user socket layout under `~/.pi/run/` (override via `PI_ACP_SOCKET_DIR` for tests / sandboxing):

- **ACP socket**: `~/.pi/run/pi-acp.sock` — NDJSON ACP wire.
- **Control socket**: `~/.pi/run/pi-acp-control.sock` — Hono HTTP over UDS for `--daemon-status` / `--daemon-stop`.
- **Lockfile**: `~/.pi/run/pi-acp.lock` containing the daemon PID.

*(Updated v1.1 — sockets relocated from `${XDG_RUNTIME_DIR:-${TMPDIR:-/tmp}}/pi-acp-${UID}.sock` to `~/.pi/run/` so everything pi-related stays under one tree. Posix-only; Windows named-pipe path dropped.)*

Lockfile acquired via `O_CREAT | O_EXCL` with PID payload. Stale-lock detection: if PID in lockfile is not alive (`kill -0`), remove and retry.

Stale-socket handling: if socket file exists but `connect()` returns `ECONNREFUSED`, client removes the stale file and proceeds to auto-spawn.

**Acceptance criteria:**

```gherkin
Given ~/.pi/run/pi-acp.sock exists but no daemon process is alive
When a client invokes pi-acp
Then the client detects the stale socket, removes it, spawns a daemon, and connects
```

### FR-5: Cross-window session visibility

`session/list` returns the union of sessions across all connected clients of the daemon, NOT just sessions owned by the requesting client.

Each returned `SessionInfo` carries `_meta.piAcp.ownedByThisConnection: boolean` so the client can render a UX hint ("opened in another window") if it wants.

Persisted-but-not-loaded sessions (in `~/.pi/agent/sessions/`) continue to be enumerable as today — daemon delegates to `SessionManager.listAll()` and merges with the in-memory registry, deduping by `sessionId`.

**Acceptance criteria:**

```gherkin
Given client A has session X live in the daemon
And client B is connected to the same daemon
When client B calls session/list
Then the response includes session X
And session X's _meta.piAcp.ownedByThisConnection is false

Given session Y exists on disk but is not currently live in the daemon
When any client calls session/list
Then the response includes session Y
And session Y's _meta.piAcp.ownedByThisConnection is false
```

### FR-6: Idle shutdown

Daemon tracks `activeConnectionCount`. State machine:

- `count > 0`: armed but not running
- `count === 0`: start `idleTimer` with `PI_ACP_DAEMON_IDLE_SECONDS` (default 600).
- New connection: cancel `idleTimer`.
- `idleTimer` fires: graceful shutdown.

Graceful shutdown:
1. Refuse new connections (close the listener).
2. Dispose all `AgentSession`s in `SessionRegistry`. Each `.dispose()` flushes any in-flight state.
3. Close all socket connections (in practice should be 0 at this point).
4. Close shared singletons (SSH pool sends `-O exit` to ControlMasters; HTTP cache drops; manifest cache drops).
5. Remove socket file + lockfile.
6. Exit 0.

**Acceptance criteria:**

```gherkin
Given a daemon with 0 active connections and idle timer running
When the idle timer fires (or PI_ACP_DAEMON_IDLE_SECONDS=2 has elapsed in test)
Then the daemon closes the listener, disposes singletons, removes socket + lockfile, and exits 0
```

### FR-7: Operator commands

`pi-acp --daemon-status`:
- If no daemon running: prints `pi-acp daemon: not running` to stderr, exit 1.
- If running: connects, requests status frame, prints JSON to stdout (uptime, connection count, session count, singleton memory rough estimates).

`pi-acp --daemon-stop`:
- If no daemon running: prints `pi-acp daemon: not running` to stderr, exit 0.
- If running: connects, sends shutdown frame, waits for daemon exit (up to 5s), prints `pi-acp daemon: stopped` to stderr, exit 0.

Both commands speak a small control-frame protocol on the same socket — frame is JSON-RPC with method `daemon/status` or `daemon/shutdown`, namespaced so it does NOT collide with the ACP method space. Daemon recognizes these methods at the socket-protocol level, before handing off to `AgentSideConnection`.

**Acceptance criteria:**

```gherkin
Given a daemon is running with 2 connected clients and 5 live sessions
When pi-acp --daemon-status is invoked
Then the output JSON contains uptime_seconds, connections: 2, sessions: 5

Given a daemon is running
When pi-acp --daemon-stop is invoked
Then the daemon disposes all state and exits 0 within 5 seconds
And the socket file is removed
```

### FR-8: ~~Backward compat escape hatch~~ (rescinded in v1.1)

Originally specified `PI_ACP_NO_DAEMON=1` / `--no-daemon` as a fallback to the v0.5 in-process path. **Removed during the v0.6 foundation refactor** (Posix-only, Bun + Hono) — see the foundation-refactor PR. There is no in-process fallback; the daemon is the only runtime path.

Rationale for the removal: maintaining a parallel in-process path doubled the test surface, kept `runtime/in-process.ts` from being deleted, and was never an actual recovery story (a daemon bug would also be hit in-process since they share `PiAcpAgent`). Users who need to bypass the daemon for debugging can `PI_ACP_DAEMON_DEBUG=1 pi-acp --daemon` in one terminal and run the client in another.

---

## 6. Non-Functional Requirements

| Category | Requirement |
|----------|-------------|
| **Latency: cold start** | First client invocation (daemon spawn + handshake) completes in <500ms on a warm filesystem. |
| **Latency: warm start** | Subsequent client invocations complete socket connect + ACP `initialize` in <50ms. |
| **Memory** | Daemon idle memory < 80MB (one pi runtime, no active sessions). Per-session overhead matches v0.5. |
| **Crash isolation** | A panic in one connection's `PiAcpAgent` must NOT crash the daemon. Daemon catches `uncaughtException` per connection, closes that socket, continues serving others. |
| **Stdout discipline** | Daemon writes nothing to its own stdout/stderr unless `PI_ACP_DAEMON_DEBUG=1`. Client stdout carries only ACP frames forwarded from daemon. |
| **Signal handling** | Daemon: `SIGINT`/`SIGTERM` → graceful shutdown. Client: `SIGINT`/`SIGTERM` → close socket → exit. |
| **Lockfile cleanup** | Daemon removes its lockfile on clean shutdown. Stale-lock detection (PID not alive) handles crash recovery. |
| **Concurrency** | Multiple clients concurrently calling `session/new` on the same daemon must not collide. `SessionRegistry` mutations protected. |
| **Backwards compat** | None — the v0.5 in-process path was deleted in the v0.6 foundation refactor (FR-8 rescinded). |

---

## 7. Risks & Assumptions

### Risks

| Risk | Severity | Likelihood | Mitigation |
|------|----------|------------|------------|
| Pi `0.69` session-replacement context invalidation breaks concurrent `AgentSession` ownership | High | Med | Phase-1 integration test runs two `AgentSession`s concurrently before declaring done. If sharing breaks, daemon spins one `AgentSession` per session-id with strict isolation; shared singletons drop to a smaller set. |
| Auto-spawn race when two clients start within ~10ms | Med | Low | Lockfile + `O_EXCL` open. Loser polls for socket file. Bounded retry. |
| Stale lockfile after daemon crash | Med | Med | PID-check: if PID in lockfile not alive (`kill -0`), reclaim. |
| Idle shutdown fires while a client is connecting | Low | Low | Timer cancellation runs on `listener.connection` event before the new socket is fully wired; race window is sub-ms but exists. Mitigation: if shutdown started, refuse new connection cleanly so client retries (auto-spawn). |
| Daemon misbehaves and accepts connections but never responds | Med | Low | Client has connect-timeout (3s). On timeout, client kills daemon (lockfile-PID → SIGKILL), removes socket, re-spawns. |
| ~~Windows named-pipe semantics differ from Unix sockets~~ | — | — | *Rescinded v1.1 — Windows support dropped in the foundation refactor (Posix-only).* |
| `--terminal-login` breaks because users expect daemon-mode | Low | Low | `--terminal-login` flag is explicit; documented to never engage daemon. |
| Shared `ResourceLoaderPool` returns stale entries when `.pi-acp.yaml` changes on disk | Med | Med | Manifest cache keyed by `stat(path).mtime`; pool entry invalidated on stat change. |
| Socket path collisions with other tools | Low | Low | Namespace under per-UID `~/.pi/run/` tree; per-user filesystem permissions bound it. |

### Assumptions

- One user, one workstation, one daemon. Cross-user is a future problem.
- Bun / Node `net.createServer` + `net.connect` work on macOS and Linux (Posix-only — Windows dropped in v1.1).
- Pi `0.75.3`'s shared state (model registry, auth storage) is safe for concurrent reads. Concurrent `createAgentSession` calls do not race on shared state. To be verified during implementation.
- ACP clients reasonably support being given a thin-client binary path — `agent_servers.<name>.command: pi-acp` requires no changes.

---

## 8. Design Decisions

### D1: Single daemon per UID, not per cwd / per project

**Options:**
1. One daemon per project.
2. One daemon per user (UID-scoped socket).

**Decision:** One per UID. ADR-0010.

**Rationale:** Project boundary is fluid; users often work across projects in the same window-set. UID is the natural identity boundary on a workstation. Cross-project `session/list` is a feature, not a leak.

### D2: Unix-socket transport, not TCP

**Options:**
1. TCP localhost.
2. Unix domain socket.

**Decision:** Unix domain socket. ADR-0010. *(v1.1 — Windows named-pipe fallback dropped; Posix-only.)*

**Rationale:** No port allocation, no firewall surface, filesystem-permission-bounded by default. TCP would require auth tokens we don't need.

### D3: Auto-spawn from thin client

**Options:**
1. User runs `pi-acp --daemon` manually (or via launchd / systemd unit).
2. First client invocation transparently spawns the daemon.

**Decision:** Auto-spawn. ADR-0010.

**Rationale:** Zero-config UX. The user already configured `agent_servers.<name>.command: pi-acp` — that's the only thing they want to write.

### D4: Idle shutdown timer

**Options:**
1. Daemon runs forever once started.
2. Idle timer (default 600s) shuts daemon down when no clients connected.

**Decision:** Idle timer. ADR-0010.

**Rationale:** Don't leave a process on the user's system forever just because they once opened Zed. 10-minute default is long enough that quick-action use cases don't pay restart cost; short enough that the daemon doesn't outlive the user's work.

### D5: Cross-window session visibility is on by default

**Options:**
1. Each connection only sees its own sessions in `session/list`.
2. `session/list` returns the union; `_meta.piAcp.ownedByThisConnection` lets clients filter.

**Decision:** Union with metadata. ADR-0010.

**Rationale:** The motivating user story. Filtering is a client-side concern.

### D6: ~~`PI_ACP_NO_DAEMON=1` escape hatch~~ (reversed in v1.1)

Originally decided to keep an escape hatch. **Reversed during the v0.6 foundation refactor**: the in-process path was deleted along with `runtime/in-process.ts`. Rationale on reversal: parallel code paths doubled the test surface without being a real recovery story (a daemon bug would also be hit in-process since both paths share `PiAcpAgent`).

### D7: Operator commands speak over a dedicated control socket (revised in v1.1)

**Original decision** (v1.0): in-band on the main socket; control methods (`daemon/status`, `daemon/shutdown`) recognized before the ACP handoff via first-frame peeking.

**Current decision** (v1.1, foundation refactor): separate control socket `~/.pi/run/pi-acp-control.sock`, served via Hono HTTP over Unix domain socket. The ACP socket is pure ACP — no first-frame peek, no `socket.unshift` dance. Operator clients (`--daemon-status` / `--daemon-stop`) use `Bun.fetch` with the unix-socket option.

**Rationale for revision:** Cleaner separation, trivially debuggable (`curl --unix-socket ~/.pi/run/pi-acp-control.sock http://x/status`), no protocol coupling between control surface and ACP wire frames. The "single socket file, single permission scope" argument from the original D7 didn't survive contact with the fragility of in-band frame sniffing.

---

## 9. File Breakdown

| File | Change | FR |
|------|--------|-----|
| `src/daemon/index.ts` | New | FR-1, FR-3, FR-6 — daemon entry; `pi-acp --daemon` lands here |
| `src/daemon/socket.ts` | New | FR-4 — per-OS socket path resolver + lockfile management |
| `src/daemon/context.ts` | New | FR-3 — `DaemonContext` interface + singleton container |
| `src/daemon/session-registry.ts` | New | FR-3, FR-5 — daemon-level `SessionRegistry` |
| `src/daemon/control.ts` | New | FR-7 — `daemon/status` / `daemon/shutdown` method handlers |
| `src/daemon/idle.ts` | New | FR-6 — idle timer logic |
| `src/client/index.ts` | New | FR-2 — thin-client entry; forwarder |
| `src/client/auto-spawn.ts` | New | FR-2 — auto-spawn helper |
| `src/client/operator.ts` | New | FR-7 — operator clients (status / stop) over the Hono control socket |
| `src/index.ts` | Modify | Top-level mode router: client (default) vs daemon (`--daemon`) vs terminal-login (`--terminal-login`) vs operator commands (`--daemon-status`, `--daemon-stop`) |
| `src/acp/agent.ts` | Modify | `PiAcpAgent` constructor accepts optional `DaemonContext`; resource composition pulls from `daemonContext.resourceLoaderPool` |
| `src/acp/session.ts` | Modify | `SessionRegistry` registration/deregistration on `newSession`/`closeSession` |
| `src/daemon/control.ts` | New | FR-7 — Hono app + Bun.serve unix-socket wiring |
| `test/component/daemon-lifecycle.test.ts` | New | FR-1, FR-6 — spawn, idle, shutdown |
| `test/component/daemon-multi-client.test.ts` | New | FR-3, FR-5 — cross-window session visibility |
| `test/component/auto-spawn.test.ts` | New | FR-2 — client auto-spawns daemon on cold start |
| `test/component/daemon-control.test.ts` | New | FR-7 — `--daemon-status`, `--daemon-stop` |
| `test/unit/control-app.test.ts` | New | FR-7 — Hono routes |
| `test/unit/socket-path.test.ts` | New | FR-4 — path resolution + ~/.pi/run/ default |
| `docs/adr/ADR-0010-daemon-client-split.md` | New | — |
| `docs/architecture/plan-runtime-daemon.md` | New | — |
| `docs/prd/PRD-002-portable-runtime.md` | Modify | Cross-reference PRD-003; note shared-state hooks |
| `README.md` | Modify | Document daemon mode + operator commands |

---

## 10. Dependencies & Constraints

- Node `net` (built-in) — socket server + client.
- Node `child_process.fork` for auto-spawn (detached: `detached: true, stdio: "ignore"`).
- Existing deps; no new runtime deps required for daemon work itself.
- `proper-lockfile` (or hand-rolled equivalent) for lockfile semantics. Cheap dep, but if avoidable, hand-roll using `O_EXCL`.
- Engines stay `>=24`.
- Pi `0.75.3` (verify concurrent session-creation safety).
- ACP SDK `^0.22.1`.

---

## 11. Rollout Plan

Phased — daemon work lands BEFORE PRD-002 backend phases so they can leverage shared singletons.

1. **Phase 0** — This PRD + ADR-0010 + plan. No code.
2. **Phase 1** — Daemon skeleton (FR-1, FR-2, FR-4). Socket transport, auto-spawn. No shared singletons yet — daemon hosts vanilla `PiAcpAgent` per connection with no cross-state. Goal: ACP wire surface unchanged from outside. *(FR-8 was specified here and rescinded — see §FR-8.)*
3. **Phase 2** — `SessionRegistry` + cross-window visibility (FR-3, FR-5). Sessions register; `session/list` returns the union; `closeSession` refcounts.
4. **Phase 3** — Idle shutdown + operator commands (FR-6, FR-7).
5. **Phases 4-11** — PRD-002 backends (`VirtualResourceLoader`, manifest, SSH, HTTP, ACP-FS, `import_resource`, cwd modes, diagnostics). Each plugs into `DaemonContext` shared singletons.
6. **Phase 12** — CHANGELOG, tag `v0.6.0`.

Phase 1 alone is shippable as an internal-only mini-release if needed.

---

## 12. Open Questions

| # | Question | Owner | Due | Status |
|---|----------|-------|-----|--------|
| Q1 | Does pi `0.75.3` permit concurrent `createAgentSession` calls without racing on shared model registry / auth storage? | Victor | Phase 1 | Open |
| Q2 | `idle timeout = 600s` reasonable, or should it be shorter for power-user multi-window scenarios? | Victor | Phase 3 | Open — start 600s; iterate based on telemetry. |
| Q3 | Should the daemon track per-session ownership at the connection level, or at a higher level (e.g., user-tagged)? | Victor | Phase 2 | Open — connection-level for v0.6; user-tag in v0.7+. |
| Q4 | ~~Windows named-pipe lockfile semantics differ from Unix; need a different approach?~~ | Victor | Phase 1 | **Closed (v1.1)** — Windows support dropped in the foundation refactor; Posix-only lockfile under `~/.pi/run/pi-acp.lock`. |
| Q5 | Crash-isolation: when a connection's `PiAcpAgent` throws, should the daemon dispose just that connection or also the connection's sessions? | Victor | Phase 1 | Open — lean dispose connection only; sessions remain in registry for resume. |
| Q6 | Should `pi-acp --daemon-status` output be human-readable text or JSON? | Victor | Phase 3 | Open — JSON for programmability, human-readable mode via `--text`. |
| Q7 | `PI_ACP_DAEMON_DEBUG=1` write debug log to where? stderr (visible in launchd / systemd logs) or a file under `~/.pi/`? | Victor | Phase 1 | Open — start stderr. |

---

## 13. Related

| Issue | Relationship |
|-------|-------------|
| PRD-001 v0.5 release | predecessor — daemon replaces v0.5's in-process model entirely (no fallback in v0.6 — see FR-8 rescission). |
| PRD-002 portable runtime | sibling — daemon hosts the shared singletons PRD-002 introduces. |
| `@earendil-works/pi-coding-agent@v0.75.3` | depends-on — concurrent session safety (Q1). |
| `@agentclientprotocol/sdk@v0.22.1` | depends-on — per-connection `AgentSideConnection`. |

---

## 14. Changelog

| Date | Change | Author |
|------|--------|--------|
| 2026-05-19 | Initial draft (v1.0) — daemon + thin-client architecture in response to multi-window / shared-state user need. | Victor |
| 2026-05-19 | v1.1 — foundation refactor follow-ups: FR-8 (`PI_ACP_NO_DAEMON=1` escape hatch) rescinded along with `runtime/in-process.ts`. D7 (operator-command transport) revised: dedicated Hono-over-UDS control socket replaces the in-band first-frame peek. Bun is the canonical runtime; Windows support dropped. | Victor |

---

## 15. Verification (Appendix)

Post-implementation checklist:

1. `pi-acp --daemon` spawns successfully; socket file appears at expected path; lockfile contains daemon PID.
2. `pi-acp` (thin client) auto-spawns daemon on first invocation; subsequent invocations reuse it (verified by stable daemon PID).
3. Two concurrent clients see each other's sessions in `session/list`.
4. `closeSession` from one client does NOT dispose a session another client also holds.
5. Daemon idle-shuts-down after `PI_ACP_DAEMON_IDLE_SECONDS` with no connected clients; socket + lockfile removed.
6. *(rescinded — was the `PI_ACP_NO_DAEMON=1` verification step; removed with FR-8.)*
7. `pi-acp --daemon-status` returns JSON when daemon is up; exits 1 with stderr message otherwise.
8. `pi-acp --daemon-stop` triggers graceful shutdown within 5s.
9. SIGKILL on daemon leaves stale lockfile; next client invocation detects PID-not-alive and reclaims.
10. Crashing one connection's agent does NOT crash daemon or other connections.

---

## 16. Implementation Skill References

Skills that MUST be loaded before working on the listed components. Skipping them is a process failure.

| Component | Skill | Why |
|---|---|---|
| Control plane (`src/daemon/control.ts`, `src/client/operator.ts`) | `hono` | Hono `app.request()` testing, `c.req.json<T>()`, `HTTPException` + `app.onError`, never use deprecated APIs (`app.fire`, `c.req.routePath`, `c.req.matchedRoutes`, `createBunWebSocket`, `getBunServer`). For UDS dial, use `Bun.fetch` with the `unix` option, not Node `http`. Chain handlers for RPC type inference; pass explicit status codes to `c.json(data, 200)`. |
| Auto-spawn / subprocess invocations | `bun-shell` | When the daemon or client needs to invoke external binaries (test fixtures, CI helpers), prefer `$` template over `Bun.spawn`. `Bun.spawn` only when IPC / PTY / AbortSignal / FileSink stdin / timeout opts are needed. Reserved for one-off helper scripts: uv-shebanged Python under `scripts/`. |
| Daemon TS strictness | `typescript-type-safety` | Ultra-strict tsconfig (`noUncheckedIndexedAccess`, `exactOptionalPropertyTypes`); `import * as z from 'zod'` namespace; `safeParse`; `ts-pattern` for exhaustive matching on `SessionEntry` state or control-plane request union. |
| Control-plane request/response shapes | `zod` | Validate every inbound control-socket request body via `@hono/zod-validator` against a Zod v4 schema (`zValidator('json', schema)`). Reject unknown keys via `.strict()`. |
| Pre-push gates | `lefthook-config` | Thin-caller pattern — `lefthook.yml` delegates to `mise run …` tasks. Pre-push runs `mise run release:check-published`, full typecheck, full lint. |
| Linting | `linting-stack` | Biome (format / general) + oxlint (TS deep rules + zod plugin). Root config; no per-package overrides. |
| Release pipeline | `greenfield-release` | Currently semantic-release; future migration to Changesets behind ADR. Trusted-publishing scope tracked. |
| Tool versions / env | `mise` | All hooks shell through `mise run …`. fnox-backed env via `_.fnox-env`. No global `mise activate`. |

Load skill via `/skill:<name>` before writing the code for that component.
